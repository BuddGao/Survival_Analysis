source('C:/Users/56359/Desktop/R/project_survial/E_step.R')

source('C:/Users/56359/Desktop/R/project_survial/M_step.R')
source('C:/Users/56359/Desktop/R/project_survial/inter_variable.R')
library(survival)
library(dplyr)
#------------------------------------------------------------------------------------------------------------

L1<-function(data,pa,m)
{ L1=0       #pi1 pi2 uncure rate  

delta=1-data[,"FAILCENS"]
pi1=exp(z%*%as.vector(c(pa[1],pa[2],pa[3])))
pi2=pi1*exp(pa[4])
pi1=1/(1+pi1)
pi2=1/(1+pi2)
L1=sum(m[,1]*log(pi2)+delta*m[,2]*log(1-pi2)+m[,3]*log(pi1)+delta*m[,4]*log(1-pi1))


return(-L1)
}

L2<-function(data,m,d,pa)
{ 
  len=length(data[,1])
  L2=0
  for(i in 1:max(data$interval))
  {
    
    k=min(which(data[,8]==i))
    z1=z[k:len,2]
    z2=z[k:len,3]
    m1=m[k:len,1]
    m3=m[k:len,3]
    summ=sum(m1*exp(pa[1]*z1+pa[2]*z2+pa[3])+m3*exp(pa[1]*z1+pa[2]*z2))
    L2=L2+log(exp(pa[1]*sum(z1[1:count[i]])+pa[2]*sum(z2[1:count[i]])+sum(d[k:(k+count[i]-1)])*pa[3])/(summ)^(count[i]))
    #L2=L2+log(exp(pa[1]*sum(z1[1:count[i]])+pa[2]*sum(z2[1:count[i]])+d[k]*pa[3])/(summ)^(count[i]))
    }
  return(-L2)
}


L3<-function(data,d,pa){
  alpha=exp(z%*%as.vector(c(pa[1],pa[2],pa[3])))
  alpha=1/(1+alpha)
  L3=sum(d[,1]*log((1-alpha))+(1-d[,1])*log(alpha))
  return(-L3)
}

mm<-function(data,i,delta,pi1,pi2,lambda2,alpha,beta2,s_t){
  s0=s_t[data$k2[i]]
  
  # if(data[i,8]==max(data[,8])){   ##final interval  
  #   if(data[i,3]==0)s0=0     ##censored
  # }
  ##treat 104  zero_1 138
  
  s1=s0^exp(beta2%*%z[i,2:3])
  s2=s0^exp(beta2%*%z[i,2:3]+lambda2)
  p1=(s2*pi2+1-pi2)*(1-alpha)+(s1*pi1+1-pi1)*alpha   #p(T>ti)
  p2=pi1*alpha+pi2*s0^(exp(beta2%*%z[i,2:3])*(exp(lambda2)-1))*exp(lambda2)*(1-alpha)   #p(T=ti)
  #print(delta*pi2*s2*(1-alpha)/p1)
  if(s2==0){
    m1=delta*pi2*s2*(1-alpha)/p1
    m3=delta*pi1*s1*alpha/p1
  }
  else{
     
      m1=delta*pi2*s2*(1-alpha)/p1+
        (1-delta)*s2*exp(lambda2)*(1-alpha)*pi2/(s2*exp(lambda2)*(1-alpha)*pi2+s1*alpha*pi1)
      m3=delta*pi1*s1*alpha/p1+(1-delta)*alpha*pi1*s1/(alpha*pi1*s1+s2*exp(lambda2)*(1-alpha)*pi2)
  }
  m2=delta*(1-pi2)*(1-alpha)/p1
  m4=delta*(1-pi1)*alpha/p1
 
  
  
  
  
  mline=c(m1,m2,m3,m4)
  
  lista=list(mline,s2,s1,s0)
  return (lista)
}

st<-function(data,beta2,lambda2){
  a=numeric()
  s=numeric()
  len=length(data[,1])
  for(i in 1:max(data$interval))
  {
    first=min(which(data[,8]==i))
    zz=z[first:len,]
    mm=m[first:len,]
    a[i]=-count[i]/sum((mm[,1]*exp(lambda2)+mm[,3])*exp(zz[,2:3]%*%beta2))
    s[i]=exp(sum(a))
  }
  lista=list(c(s,0),c(a,0))
  return(lista)
}
#---------------------------------------------------------------------------------------------------------------
#data-preprocessing


data=e1684 #dataset used
##select control group
original_data=e1684%>%filter(TRT%in%c(0))%>%arrange(FAILTIME)
data=pre-processed(original_data)

len=length(data[,1])
data=data[,1:7]
inter=processed(data)
data=inter[[1]]
count=inter[[2]]

logi1=glm(CURED~AGE+SEX+FAVOR,family = binomial(link = "logit"),data=data)
beta1<-logi1$coefficients[1:3]
lambda1<-logi1$coefficients[4]
# beat1=beta1_treat
# lambda1=lambda1_treat

sur<-Surv(data$FAILTIME,data$FAILCENS)
cox=coxph(sur~AGE+SEX+FAVOR,data=data)
beta2<-cox$coef[1:2]
 lambda2<-cox$coef[3]
# beta2=beta2_treat
# lambda2=lambda2_treat

logi3=glm(FAVOR~AGE+SEX,family = binomial(link = "logit"),data=data)
 w<-logi3$coefficients
 # w=w_treat

p<-matrix(0,nrow=len,ncol=1)
m<-matrix(0,nrow=len,ncol=4)
d<-matrix(0,nrow=len,ncol=1)
s2=matrix(0,nrow=len,ncol=1)   #record survival rate
s1=matrix(0,nrow=len,ncol=1) 
h2=matrix(0,nrow=len,ncol=1)   #record survival rate
h1=matrix(0,nrow=len,ncol=1)
s0=matrix(0,nrow=len,ncol=1)


delta=1-data$FAILCENS
z=as.matrix(cbind(1,data[,"AGE"],data[,"SEX"]))

error=10
times=0

#----------------------------------------------------------------------------------------------------------------
#Modeling

for(i in 1:len)   #nice
{
  if(data$FAVOR[i]==1 & data$CURED[i]==0){m[i,1]=1}
  if(data$FAVOR[i]==1 & data$CURED[i]==1){m[i,2]=1}
  if(data$FAVOR[i]==0 & data$CURED[i]==0){m[i,3]=1}
  if(data$FAVOR[i]==0 & data$CURED[i]==1){m[i,4]=1}
}
while(error>10^(-6)){
  pi1=exp(z%*%beta1)
  
  pi2=pi1*exp(lambda1)
  pi2=1/(1+pi2)
  
  pi1=1/(1+pi1)
  
  #pi2=matrix(1,nrow=140,ncol=1)
  alpha=1/(1+exp(z%*%w))
  listb=st(data,beta2,lambda2)
   s_t=listb[[1]]
   h_0=-listb[[2]]
   for(i in 1:len){
     h1[i,]=h_0[data$k2[i]]*exp(beta2%*%z[i,2:3])
     h2[i,]=h_0[data$k2[i]]*exp(c(lambda2,beta2)%*%z[i,])
   }
  for(i in seq(len)){
    lista=mm(data,i,delta[i],pi1[i],pi2[i],lambda2,alpha[i],beta2,s_t)
    m[i,]=lista[[1]]
    s2[i,]=lista[[2]]
    s1[i,]=lista[[3]]
    s0[i,]=lista[[4]]
    d[i,1]=m[i,1]+m[i,2]
  }
  
  result1=optim(par=c(beta1,lambda1),fn=L1,data=data,m=m)
  result2=optim(par=c(beta2,lambda2),fn=L2,data=data,m=m,d=d)
  result3=optim(par=w,fn=L3,data=data,d=d)
  
  
  
  
  beta1_new=result1$par[1:3]
  lambda1_new=result1$par[4]
  #beta1_intercept_new=beta1_new[1]+lambda1_new
  beta2_new=result2$par[1:2]
  lambda2_new=result2$par[3]
  w_new=result3$par
  

  
  error1=max(abs(beta1_new-beta1)/abs(beta1))
  error2=max(abs(lambda1_new-lambda1)/abs(lambda1))
  error3=max(abs(beta2_new-beta2)/abs(beta2))
  error4=max(abs(lambda2_new-lambda2)/abs(lambda2))
  error5=max(abs(w_new-w)/abs(w))
  error=max(c(error1,error2,error3,error4,error5))

  beta1=beta1_new
  lambda1=lambda1_new
  beta2=beta2_new
  lambda2=lambda2_new
  w=w_new
  #beta1_intercept=beta1_intercept_new
  
  times=times+1
  print(error)
  print(times)
}



# f1=h1*s1
# f2=h2*s2
# s_1=s_0^(beta2%*%z)
# s_2=s_0^(c(lambda1,beta[2:3])*z)
# h_1=h_0*exp(beta2%*%z[2:3])
# h_2=h_0*exp(c(lambda2.beta)%*%z)

#output:alpha:the probility in unfavorable.   s2: the survival rate in favarable.    pi1: cure rate in unfav.  p2: cure in favor

#Ls=sum(log(alpha*(pi1*f1)^(1-delta)*(pi1*s1+1-pi1)^delta+(1-alpha)*(pi2*f2)^(1-delta)*(pi2*s2+1-pi2)^(delta)))

