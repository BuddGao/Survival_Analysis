xm1234=function(i,delta,pi1,pi2,lambda2,alpha,beta,s_t)
{
  s0=s_t[data$k2[i]]
  s1=s0^exp(beta2%*%z[i,2:3])
  s2=s0^exp(beta2%*%z[i,2:3]+lambda2)
  p=s2*pi2*(1-alpha)+(s1*pi1+1-pi1)*alpha
  m1=delta*pi2*s2*(1-alpha)/p+
    (1-delta)*s2*exp(lambda2)*(1-alpha)*pi2/(s2*exp(lambda2)*(1-alpha)*pi2+s1*alpha*pi1)
  
  m2=delta*(1-pi2)*(1-alpha)/p
  m3=delta*pi1*s1*alpha/p+(1-delta)*alpha*pi1*s1/(alpha*pi1*s1+s2*exp(lambda2)*(1-alpha)*pi2)
  m4=delta*(1-pi1)*alpha/p  
  return(c(m1,m2,m3,m4))
}


xL1<-function(data,pa,m)
{
  pi1=exp(z%*%as.vector(c(pa[1],pa[2],pa[3])))       
  pi1=pi1/(1+pi1)
  L1=sum(m[,3]*log(pi1)+delta*m[,4]*log(1-pi1))
  return(-L1)
}

xL3<-function(data,d,pa)
{
  alpha=exp(z2%*%as.vector(c(pa[1],pa[2])))
  alpha=1/(1+alpha)
  L3=sum(d*log(1-alpha)+(1-d)*log(alpha))
  return(-L3)
}
st<-function(data,beta2,lambda2)
{
  #Survival function at time t
  a=numeric()
  s=numeric()
  n=dim(data)[1]
  for(i in 1:max(data$interval))
  {
    first=min(which(data[,8]==i))
    zz=z[first:n,]
    mm=m[first:n,]
    a[i]=-count[i]/sum((mm[,1]*exp(lambda2)+mm[,3])*exp(zz[,2:3]%*%beta2))
    s[i]=exp(sum(a))
  }
  return(s)
}

ht<-function(data,beta2,lambda2)
{
  #Hazard function at time t
  a=numeric()
  s=numeric()
  n=dim(data)[1]
  for(i in 1:max(data$interval))
  {
    first=min(which(data[,8]==i))
    zz=z[first:n,]
    mm=m[first:n,]
    a[i]=count[i]/sum((mm[,1]*exp(lambda2)+mm[,3])*exp(zz[,2:3]%*%beta2))
  }
  return(a)
}



raw=zero_1[,1:7]


beta1_m<-matrix(0,nrow=140,ncol=3)
lambda1_m<-matrix(0,nrow=140,ncol=1)
beta2_m<-matrix(0,nrow=140,ncol=2)
lambda2_m<-matrix(0,nrow=140,ncol=1)
w_m<-matrix(0,nrow=140,ncol=2)

beta1_s=beta1
lambda1_s=lambda1
beta2_s=beta2
lambda2_s=lambda2
w_s=w

##cut each sample
for(j in 1:140){
  
  beta1=beta1_s
  lambda1=lambda1_s
  beta2=beta2_s
  lambda2=lambda2_s
  w=w_s
  
  
  
  error=10
  raw1=raw
  raw1=raw1[-j,]
  inter=processed(raw1)
  raw1=inter[[1]]
  count=inter[[2]]
  m1=m[-j,]
  d1=d[-j]
  z=as.matrix(cbind(1,raw1[,"AGE"],raw1[,"SEX"]))
  delta=1-raw1$FAILCENS
  times=0
  z2=z[,c(1,3)]
  data=raw1
  len=length(data)
  while(error>10^(-2)){
    pi1=exp(z%*%beta1)
    pi1=pi1/(1+pi1)
    alpha=1/(1+exp(z2%*%w))   #1 unfavor 
    s_t=st(data,beta2,lambda2)
   
    # for(i in 1:len){
    #   h1[i,]=h_0[data$k2[i]]*exp(beta2%*%z[i,2:3])
    #   h2[i,]=h_0[data$k2[i]]*exp(c(lambda2,beta2)%*%z[i,])
    # }
   
    for(i in 1:len)
    { 
      m1[i,]=xm1234(i,delta[i],pi1[i],1,lambda2,alpha[i],beta2,s_t)
      d1[i]=m1[i,1]+m1[i,2]
    }
    
    result1=optim(par=c(beta1,lambda1),fn=xL1,data=data,m=m1)
    result2=optim(par=c(beta2,lambda2),fn=L2,data=data,m=m1,d=d1)
    result3=optim(par=w,fn=xL3,data=data,d=d1)
    
    beta1_new=result1$par[1:3]
    beta2_new=result2$par[1:2]
    lambda2_new=result2$par[3]
    w_new=result3$par 
    
    error1=max(abs(beta1_new/beta1-1))
    error2=max(abs(beta2_new/beta2-1))
    error3=max(abs(w_new/w-1))
    error4=max(abs(lambda2_new/lambda2-1))
    error=max(c(error1,error2,error3,error4))
    
    beta1=beta1_new
    beta2=beta2_new
    lambda2=lambda2_new
    w=w_new
    beta1_intercept=beta1_intercept_new
    
    times=times+1
  
  
  
  
  beta1_new=result1$par[1:3]
  lambda1_new=result1$par[4]
  #beta1_intercept_new=beta1_new[1]+lambda1_new
  beta2_new=result2$par[1:2]
  lambda2_new=result2$par[3]
  w_new=result3$par
  
  # print(beta1_new)
  # print(lambda1_new)
  # print(beta2_new)
  # print(lambda2_new)
  # print(w_new)
  
  
  # beta1_m[i,]=beta1
  # lambda1_m[i]=lambda1
  # beta2_m[i,]=beta2
  # lambda2_m[i]=lambda2
  # w_m[i,]=w
  

  
  times=times+1
  
  #print(beta1_intercept)

}
  beta1_m[j,]=beta1
  lambda1_m[j]=lambda1
  beta2_m[j,]=beta2
  lambda2_m[j]=lambda2
  w_m[j,]=w
  print(j)

}


#compute mean
beta1_mean=c(mean(beta1_m[,1]),mean(beta1_m[,2]),mean(beta1_m[,3]))
beta2_mean=c(mean(beta2_m[,1]),mean(beta2_m[,2]))
lambda2_mean=mean(lambda2)
w_mean=c(mean(w_m[,1]),mean(w_m[,2]))

#compute variance
beta1_variance=1/139*c(sum((beta1_mean[1]-beta1_m[,1])^2),sum((beta1_mean[2]-beta1_m[,2])^2),sum((beta1_mean[3]-beta1_m[,3])^2))
beta2_variance=1/139*c(sum((beta2_mean[1]-beta2_m[,1])^2),sum((beta2_mean[2]-beta2_m[,2])^2))
lambda2_variance=1/139*sum((lambda2_mean-lambda2_m)^2)
w_variance=1/139*c(sum((w_mean[1]-w_m[1])^2),sum((w_mean[2]-w_m[2])^2))

#compute bias
beta1_bias=beta1_mean-beta1_s
beta2_bias=beta2_mean-beta2_s
lambda2_bias=lambda2_mean-lambda2_s
w_bias=w_mean-w_s


#compute CI
beta1_order=beta1_m[order(beta1_m[,1],beta1_m[,2],beta1_m[,3]),]
beta2_order=beta2_m[order(beta2_m[,1],beta2_m[,2]),]
lambda2_order=sort(lambda2_m)
w_order=w_m[order(w_m[,1],w_m[,2]),]

beta1_interval=rbind(beta1_order[4,],beta1_order[136,])
beta2_interval=rbind(beta2_order[4,],beta2_order[136,])
lambda2_interval=rbind(lambda2_order[4],lambda2_order[136,])
w_interval=rbind(w_order[4,],w_w_order[136,])

