processed<-function(data){
  len=length(data[,1])
  a=subset(data,data$FAILCENS==1)
  b=a[!duplicated(a$FAILTIME),]
  dup=length(a[,1])
  nodup=length(b[,1])
  interval=matrix(0,nrow=len,ncol=1)
  for(i in 1:len){#compute interval
    time=data[i,2]
    for(j in 1:(nodup-1)){
      if(time>=b[j,2]&time<b[j+1,2]){
        interval[i]=j  
        break
      }}
      if(time>=b[nodup,2]){
        interval[i]=j+1
       
      }
        
      }
    
  data=cbind(data,interval)
  
  # count=matrix(0,nrow=nodup,ncol=1)
  # for(i in 1:nodup){  #compute di
  #   time=b[i,2]
  #   c=0
  #   for(j in 1:dup){
  #     if(time==a[j,2]){
  #       c=c+1
  #     }
  #   }
  #   count[i]=c
  # }
  
  k2=numeric()
  uniq_failure=unique(data$FAILTIME*data$FAILCENS)
  for(i in 1:len)
  {
    k2[i]=length(which(uniq_failure<=data$FAILTIME[i]))-1
  }
  data=cbind(data,k2)
  
  return(data)
  #return(list(data,count))
}